
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.StringTokenizer;

import com.sun.javafx.geom.Rectangle;

import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.util.Duration;



/**
 *
 *@author 219002773_NC_Brown
 *@version Network Project
 */
public class Client extends Application implements Runnable{
	private Socket clientConnect ;
	private String grayURL = "/api/GrayScale" ;
	private String erosionURL = "/api/Erosion" ;
	private String dilationURL = "/api/Dilation" ;
	private String cannyURL = "/api/Canny" ;
	private String fastURL = "/api/Fast" ;
	private String strExtension  = "py" ;
	private String cannyfeaturesURL = "/api/CannyFeatures" ; 
	private String fastfeaturesURL = "/api/FastFeatures" ;
	FileInputStream FileReader = null ;
	private BorderPane border = null ;
	private TextArea Space = new TextArea() ;
	private HBox box1 = new HBox() ;
	private HBox box2 = new HBox() ;
	private VBox vbox1 = new VBox() ;
	private VBox vbox2 = new VBox() ;
	private Scene scene = null ;
	private final Integer Port = 5000 ;
	private InputStream inputstream = null ;
	private OutputStream outputstream = null ;
	private BufferedReader bufferedreader = null ;
	private DataOutputStream dataoutputstream = null ;
	private BufferedOutputStream bufferedoutputstream = null ;

	
	private Integer Number1 ;
	private Integer Number2 ;
	private double Gradient ; 
	private GridPane ImageGrid ;
	private GridPane grid = new GridPane() ;
	
	Image[] imgArray = new Image[6] ;
	ImageView[] imgvArray = new ImageView[6] ;
	
	String str1 = "" ;
	String str2 = "" ;
	String str3 = "" ;
	String str4 ="" ;
	
	private ArrayList<Button> btnArray = new ArrayList<>() ;
	/**
	 * Method to instantiate nodes
	 */
	private void HelperMethod()
	{	
		border = new BorderPane() ;
		//Instantiations of button's
		
		btnArray.add(new Button("Connect")) ;
		btnArray.add(new Button("Fast")) ;
		btnArray.add(new Button("Canny")) ;
		btnArray.add(new Button("GrayScale")) ;
		btnArray.add(new Button("Erosion")) ;
		btnArray.add(new Button("Dilation")) ;
		
		vbox1.setPrefHeight(200);
		vbox1.setPrefWidth(90);
		vbox1.setPadding(new Insets(42,42,42,42));
		Space = new TextArea() ;
		Space.setPrefHeight(91);
		Space.setPrefWidth(401);
		grid.setPrefHeight(202);
		grid.setPrefWidth(202);
		grid.setAlignment(Pos.CENTER);
		grid.setPadding(new Insets(4,4,4,4));
		
	}
	/**
	 * Method to allow client server connection
	 */
	private void clientConnectFunc()
	{
		try {
			clientConnect = new Socket("localhost",Port) ;
			Space.appendText("Client connected to the server\r\n");
			//bind streams
		    inputstream = clientConnect.getInputStream() ;
			bufferedreader = new BufferedReader(new InputStreamReader(inputstream)) ;
			outputstream = clientConnect.getOutputStream() ;
		    bufferedoutputstream = new BufferedOutputStream(outputstream) ;
			dataoutputstream = new DataOutputStream(bufferedoutputstream) ;
			
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	/**
	 * Method to add nodes onto the borderpane layout
	 * @return
	 */
	private BorderPane getBorder()
	{		
		HelperMethod() ;
		box1.getChildren().add(btnArray.get(0)) ;
		box2.getChildren().addAll(btnArray.get(3),btnArray.get(4),btnArray.get(5),Space,btnArray.get(2),btnArray.get(1)) ;
		vbox1.getChildren().addAll(ImageGrid) ;
		vbox2.getChildren().addAll(box2,Space) ;
		border.setTop(box1);
		border.setCenter(vbox1);
		border.setBottom(vbox2);		
		return border ;
	}
	/**
	 * Method to allow swapping of images
	 */
	private void ImageClick()
	{
		imgvArray[0].setOnMouseClicked(e ->
		{
			sendImageDataToServer(cannyfeaturesURL,"img0.jpg") ;
			if(Gradient > 2.0)
			{
				imgvArray[0].setImage(imgvArray[5].getImage()) ;
			}
			else
				imgvArray[0].setImage(imgvArray[4].getImage()) ;
		});
		imgvArray[1].setOnMouseClicked(e ->
		{
			sendImageDataToServer(cannyfeaturesURL,"img1.jpg") ;
			if(Gradient > 2.0)
			{
				imgvArray[1].setImage(imgvArray[5].getImage()) ;
			}
			else
				imgvArray[1].setImage(imgvArray[4].getImage()) ;
		});
		imgvArray[2].setOnMouseClicked(e ->
		{
			sendImageDataToServer(cannyfeaturesURL,"img2.jpg") ;
			if(Gradient > 2.0)
			{
				imgvArray[2].setImage(imgvArray[5].getImage()) ;
			}
			else
				imgvArray[2].setImage(imgvArray[4].getImage()) ;
		});
		imgvArray[3].setOnMouseClicked(e ->
		{
			sendImageDataToServer(cannyfeaturesURL,"img3.jpg") ;
			if(Gradient > 2.0)
			{
				imgvArray[3].setImage(imgvArray[5].getImage()) ;
			}
			else
				imgvArray[3].setImage(imgvArray[4].getImage()) ;
		});			
		
	}
	/**
	 * Method to initialize images and add into grid
	 * @return
	 */
	private GridPane getLayout()
	{
		int i = 0 ;
		ImageGrid = new GridPane() ;
		while(i < 6)
		{
			imgArray[i] = new Image("img"+i+".jpg") ;
			imgvArray[i] = new ImageView(imgArray[i]) ;
			switch(i)
			{
			case 0:
				ImageGrid.add(imgvArray[i], 1, 1);
				break ;
			case 1:
				ImageGrid.add(imgvArray[i], 1, 2);
				break ;
			case 2:
				ImageGrid.add(imgvArray[i], 2, 1);
				break ;
			case 3:
				ImageGrid.add(imgvArray[i], 2, 2);
				break ;
		}
		i ++ ;
	}

        HelperMethod() ;
		box1.getChildren().add(btnArray.get(0)) ;
		box2.getChildren().addAll(btnArray.get(3),btnArray.get(4),btnArray.get(5),Space,btnArray.get(2),btnArray.get(1)) ;
		vbox1.getChildren().addAll(ImageGrid) ;
		vbox2.getChildren().addAll(box2,Space) ;
		border.setTop(box1);
		border.setCenter(vbox1);
		border.setBottom(vbox2);			
		grid.add(border, 1, 1);

		return grid ;
	}
	/**
	 * Method to display the GUI
	 * @param stage
	 */
	private void GUI(Stage stage)
	{ 
		 scene = new Scene(getLayout(),700,700) ;
	  
	  stage.setTitle("A template matcher(Find cars in a given set of images)");
	  stage.setScene(scene);
	  stage.show();
	  Thread t = new Thread(this) ;
	  t.start();
	 
	  
	}
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		GUI(primaryStage) ;
	}
	public static void main(String[] args)
	{
		launch(args) ;
	}
	/**
	 * Method to post request to the server in HTTP protocol
	 * @param service
	 * @param fileEncode
	 */
	private void writingToServerMethod(String service,String fileEncode)
	{
		byte[] bytesToSend = fileEncode.getBytes() ;
		try
		{		
		dataoutputstream.write(("POST " +  service + " HTTP/1.1\r\n").getBytes());
		dataoutputstream.write(("Content-Type: " + "application/text\r\n").getBytes()) ;
		dataoutputstream.write(("Content-Length: " + fileEncode.length() + "\r\n").getBytes()) ;
		dataoutputstream.write(("\r\n").getBytes());
		dataoutputstream.write(bytesToSend);
		dataoutputstream.write(("\r\n").getBytes());
		dataoutputstream.flush();
		WriteInfoToSpace(1) ;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * Method to send image to the server for modification
	 * @param service
	 * @param Imageurl
	 */
	private void sendImageDataToServer(String strRes,String Imageurl)
	{
		String imgFile = null ;
		
		try {
			File imageU = new File("../computerscience(NetworkingProject)/src/" + Imageurl) ;
            FileReader = new FileInputStream(imageU) ;
			byte[] bytes = new byte[(int)imageU.length()] ;
			FileReader.read(bytes) ;
			
			imgFile = new String(Base64.getEncoder().encodeToString(bytes)) ;
			byte[] bytesToSend = imgFile.getBytes() ;
			writingToServerMethod(strRes,imgFile) ;
			while(!(str4 = bufferedreader.readLine()).equals(""))
			{
				str3 += str4 ;
			}
			try {
				 str1 = "" ;
				 str2 = "" ;
				while((str1 = bufferedreader.readLine()) != null)
				str2 += str1 ;
				
				String ServerData = str2.substring(str2.indexOf('\'') + 1,str2.lastIndexOf('}') -1) ;
				StringTokenizer tokens = new StringTokenizer(ServerData,":") ;
				String subString = ServerData.substring(2,4) ;
				if(subString.startsWith(strExtension)) {
					FindingImgeGradientUsingCannyFeater(ServerData) ;
				}
				else
				{
				byte[]DecodedData = Base64.getDecoder().decode(ServerData) ;
				//Display The Image
				
				Image newImage = new Image(new ByteArrayInputStream(DecodedData)) ;
				imgvArray[0].setImage(newImage);
				}
				}
				catch(IOException ex)
				{
					ex.printStackTrace();
				}
		
		}
		catch(IOException ex)
		{
			ex.printStackTrace();
		}
		finally {
			try
			{
			clientConnect.close() ;
			dataoutputstream.close() ;
			}catch(IOException ex)
			{
				ex.printStackTrace();
			}
		}
	}
	/**
	 * Method to break data received from server in json format
	 * @param ServerInfo
	 */
	private void FindingImgeGradientUsingCannyFeater(String ServerInfo)
	{
		StringTokenizer tokens0 = new StringTokenizer(ServerInfo,":") ;
		String ServerInfo2 ="" ;
		int index = 0 ;
		while(index < 4) {
			if(index >=3) {
				ServerInfo2 = ServerInfo2.substring(2,ServerInfo2.length()-2) ;
			StringTokenizer tokens = new StringTokenizer(ServerInfo2,",") ;
			Number1 = Integer.parseInt(tokens.nextToken()) ;
			Number2 = Integer.parseInt(tokens.nextToken().trim()) ;
			System.out.println(Number1) ;
			System.out.println(Number2) ;
			Gradient = (double)(Number2)/Number1 ;
			System.out.println(Gradient) ;
			
			}else
				ServerInfo2 = tokens0.nextToken() ;
	
			index++ ;
		}
		//appending
		WriteInfoToSpace(0) ;
	}
	/**
	 * Method to append info into Space
	 * @param i
	 */
	private void WriteInfoToSpace(int i)
	{
		if(i == 0)
			Space.appendText("\nRoughly significant\nGradient="+Gradient+"\r\n");
		else if(i == 1)
		{
			Space.appendText("POST Request Sent\r\n");
		}
		
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		while(true) {
		btnArray.get(0).setOnAction(e ->
		{
		clientConnectFunc() ;	
		});
		btnArray.get(1).setOnAction(e ->
		{
		sendImageDataToServer(fastURL,"img0.jpg") ;
		});
		btnArray.get(2).setOnAction(e ->
		{
		sendImageDataToServer(cannyURL,"img1.jpg") ;		//
		});
		btnArray.get(3).setOnAction(e ->
		{
		sendImageDataToServer(grayURL,"img2.jpg") ;		//
		});
		btnArray.get(4).setOnAction(e ->
		{//
		sendImageDataToServer(erosionURL,"img3.jpg") ;	//
		});
	   btnArray.get(5).setOnAction(e ->
		{
		 sendImageDataToServer(dilationURL,"img2.jpg") ;		
		});	
	   ImageClick() ;
	}
	}
    }
